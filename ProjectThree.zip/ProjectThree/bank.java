package ProjectThree;

public class bank {

    public int deposit(customer balance, int enrty){
      int temp =  balance.getbalance() + enrty;
        System.out.println(temp);

       return temp;


    }
    public int withdrawl(customer balance, int enrty){
        int temp =  balance.getbalance() - enrty;
        System.out.println(temp);
        return temp;

    }












}
