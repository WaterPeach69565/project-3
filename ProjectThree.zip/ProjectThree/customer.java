package ProjectThree;

import weekEleven.ProjectEleven.move;

import java.util.ArrayList;

public class customer {
    private String name;
    private int pin;
    private int balance;

    public customer(String name, int pin,int balance){
        this.name = name;
        this.pin = pin;
        this.balance = balance;
    }
    public String getName(){
        return name;
    }
    public int getPin(){
        return pin;
    }

    public int getbalance(){return balance;}





}

